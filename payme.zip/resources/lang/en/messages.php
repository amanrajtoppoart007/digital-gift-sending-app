<?php

return [
    'franchisee_registration' => 'Welcome to Ashirvaad Online Your Reg.No. :reg_number Your services will be initiated shortly',
];
