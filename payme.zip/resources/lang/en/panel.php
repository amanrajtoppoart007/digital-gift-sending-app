<?php

return [
    'site_title' => 'Online Ashirvaad',
];
